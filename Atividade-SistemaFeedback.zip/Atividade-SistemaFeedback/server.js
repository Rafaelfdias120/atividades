const express = require('express');
const path = require('path');
const app = express();
const PORT = 3000;

// Middleware para ler dados do formulário e servir arquivos estáticos
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public')); 

// Banco de dados em memória
let feedbacks = [];

// Rota para cadastrar feedback
app.post('/feedbacks/enviar', (req, res) => {
    const { nome, comentario } = req.body;
    if (nome && comentario) {
        feedbacks.push({ id: Date.now().toString(), nome, comentario });
    }
    res.redirect('/feedbacks/lista');
});

// Rota para listar feedbacks (retorna JSON para o script.js)
app.get('/api/feedbacks', (req, res) => {
    res.json(feedbacks);
});

// Quando o usuário for para /feedbacks/lista, enviamos o index.html
app.get('/feedbacks/lista', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Rota para remover feedback
app.post('/feedbacks/remover', (req, res) => {
    const { id } = req.body;
    feedbacks = feedbacks.filter(f => f.id !== id);
    res.redirect('/feedbacks/lista');
});

// Serve as páginas HTML
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/feedbacks/lista', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html'))); // Usaremos o mesmo HTML para simplificar

app.listen(PORT, () => console.log(`Servidor em http://localhost:${PORT}`));