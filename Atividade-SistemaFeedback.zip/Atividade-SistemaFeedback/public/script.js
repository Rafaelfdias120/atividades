async function carregarFeedbacks() {
    const response = await fetch('/api/feedbacks');
    const feedbacks = await response.json();
    const container = document.getElementById('feedbacks-container');
    
    container.innerHTML = feedbacks.map(f => `
        <div class="feedback-card">
            <strong>${f.nome}</strong>
            <p>${f.comentario}</p>
            <form action="/feedbacks/remover" method="POST">
                <input type="hidden" name="id" value="${f.id}">
                <button type="submit" class="btn-remove">Remover</button>
            </form>
        </div>
    `).join('');
}

async function carregarFeedbacks() {
    try {
        const response = await fetch('/api/feedbacks');
        const feedbacks = await response.json();
        const container = document.getElementById('feedbacks-container');
        
        if (feedbacks.length === 0) {
            container.innerHTML = '<p>Nenhum feedback encontrado.</p>';
            return;
        }

        container.innerHTML = feedbacks.map(f => `
            <div class="feedback-card" style="border: 1px solid #ddd; margin-bottom: 10px; padding: 10px;">
                <strong>${f.nome}</strong>
                <p>${f.comentario}</p>
                <form action="/feedbacks/remover" method="POST">
                    <input type="hidden" name="id" value="${f.id}">
                    <button type="submit" style="background: red; color: white;">Remover</button>
                </form>
            </div>
        `).join('');
    } catch (erro) {
        console.error("Erro ao carregar feedbacks:", erro);
    }
}

// Executa a função assim que a página carrega
window.onload = carregarFeedbacks;
// Carrega a lista se estiver na URL de listagem ou apenas ao iniciar
carregarFeedbacks();